select FirstName from Employees where Title='Sales Representative' and BirthDate=(select min(BirthDate) from Employees)

Select distinct Employees.FirstName,c.CompanyName,p.ProductName
from customers as c
	inner join orders on orders.CustomerID=c.CustomerID
	inner join [Order Details] as od on od.OrderID=orders.OrderID
	inner join Products as p on od.ProductID=p.ProductID,Employees
where Orders.EmployeeID=(
select EmployeeID from Employees 
where Title='Sales Representative' and 
BirthDate=(select min(BirthDate) from Employees))
and Employees.EmployeeID=Orders.EmployeeID

