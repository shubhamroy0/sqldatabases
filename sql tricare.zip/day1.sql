create database OLTP
create DATABASE OLTP
go
go
drop table Sales.Customer
create schema Sales
go
create schema Purchasing
go
create schema Person
go
create schema Production
go
create schema HumanResources
go
create table Sales.Customer
(
	CustomerID int primary key,
	TerritoryID int,
	AccountNumber int,
	CustomerType varchar(20),
	rowguid int unique,
	ModifiedDate date,
)
create table Sales.SalesOrderHeader
(
	SalesOrderID int primary key,
	RevisionNumber int,
	OrderDate date,
	DueDate date,
	ShipDate date,
	Status varchar(20),
	OnlineOrderFlag bit,
	SalesOrderNumber int unique,
	PurchaseOrderNumber int,
	AccountNumber int,
	CustomerID int,
	ContactID int,
	SalesPersonID int,
	TerritoryID int,
	BillTOAddressID int,
	ShipToAddressID int,
	CreditCardApprovalCode varchar(10),
	CurrentRateID varchar(20),
	SubTotal int,
	TaxAmt int,
	Freight varchar(20),
	TotalDue int,
	Comment varchar(100),
	rowguid int unique,
	ModifiedDate date,
	CreditCardID varchar(20)
)
go
create table Sales.CurrencyRate
(
	CurrencyRateID int primary key,
	CurrencyRateDate date unique,
	FromCurrencyCode varchar(20) unique,
	ToCurrencyCode varchar(20) unique,
	AverageRate int,
	EndOfDayRate int,
	ModifiedDate date
)
go
create table Sales.SalesOrderHeaderSalesReason
(
	SalesOrderID int,
	SalesReasonID int,
	ModifiedDate date
	constraint pk_SalesOrderHeaderSalesReason primary key(SalesOrderID,SalesReasonID)
)
create table Sales.SalesTaxRate
(
	SalesTaxRateID int primary key,
	StateProvinceID int unique,
	TaxType int unique,
	TaxRate varchar(20),
	Name varchar(100),
	rowguid int unique,
	ModifiedDate date,
)
create table Sales.SalesTerritoryHistory
(
	SalesPersonID int,
	TerritoryID int,
	StartDate date,
	EndDate date,
	rowguid int unique,
	ModifiedDate date,
	constraint pk_SalesTerritoryHistory primary key(SalesPersonID,TerritoryID,StartDate)
)
create table Sales.SalesTerritory
(
	TerritoryID int primary key,
	Name varchar(100) unique,
	CountryRegionCode varchar(20),
	[Group] varchar(20),
	SalesYTD varchar(20),
	SalesLastYear bigint,
	CostYTD varchar(20),
	CostLastYear bigint,
	rowguid int unique,
	ModifiedDate date,
)
create table Sales.Individual
(
	CustomerID int primary Key,
	ContactID int,
	Demographics int,
	ModifiedDate date
)
create table Sales.Store
(
	CustomerID int primary key,
	Name varchar(20),
	Demographics int,
	rowguid int unique,
	ModifiedDate date,
	SalesPersonID int
)
create table Sales.StoreContact
(
	CustomerID int,
	ContactID int,
	ContactTypeID int,
	rowguid int unique,
	ModifiedDate date,
	constraint pk_StoreContact primary key(CustomerID,ContactID)
)
create table Sales.CustomerAddress
(
	CustomerID int,
	AddressID int,
	AddressTypeID int,
	rowguid int unique,
	ModifiedDate date,
	constraint pk_CustomerAddress primary key(CustomerID,AddressID)
)
create table Sales.SalesPerson
(
	SalesPersonID int primary key,
	TerritoryID int,
	SalesQuota int,
	Bonus int,
	CommissionPct varchar(20),
	SalesYTD varchar(20),
	SalesLastYear int,
	rowguid int unique,
	ModifiedDate date,
)
create table Sales.SalesPersonQuotaHistory
(
	SalesPersonID int,
	QuotaDate date,
	SalesQuota int,
	rowguid int unique,
	ModifiedDate date,
	constraint pk_SalesPersonQuotaHistory  primary key(SalesPersonID,QuotaDate)
)
create table Sales.Currency
(
	CurrencyCode int primary key,
	Name varchar(100) unique,
	ModifiedDate date
)
create table Sales.ShoppingCartItem
(
	ShoppingCartItemID int primary key,
	ShoppingCartID int,
	Quatity int,
	ProductID int,
	DateCreated date,
	ModifiedDate date,
)
create table Sales.SalesReason
(
	SalesReasonID int primary key,
	Name varchar(100),
	ReasonType varchar(100),
	ModifiedDate date,
)
create table Sales.CreditCard
(
	CreditCardID int primary key,
	CardType varchar(20),
	CardNumber bigint,
	ExpYear varchar(20),
	ExpMonth varchar(20),
	ModifiedDate date,
)
create table Sales.SalesOrderDetail
(
	SalesOrderID int,
	SalesOrderDetailID int,
	CarrierTrackingNumber bigint,
	OrderQty int,
	ProductID int,
	SpecialOfferID int,
	UnitPrice int,
	UnitPriceDiscount int,
	LineTotal int,
	rowguid int unique,
	ModifiedDate date,
	constraint pk_SalesOrderDetail primary key(SalesOrderID,SalesOrderDetailID)
)
create table Sales.SpecialOfferProduct
(
	SpecialOrderID int,
	ProductID int,
	rowguid int unique,
	ModifiedDate date
	constraint pk_SpecialOfferProduct primary key(SpecialOrderID,ProductID)
)
create table Sales.SpecialOffer
(
	SpecialOfferID int primary key,
	Description varchar(100),
	DiscountPct varchar(100),
	Type varchar(20),
	Category varchar(20),
	StartDate date,
	EndDate date,
	MinQty int,
	MaxQty int,
	rowguid int unique,
	ModifiedDate date
)
create table Sales.ContactCreditCard
(
	ContactID int,
	CreditCardID int,
	ModifiedDate date,
	constraint pk_ContactCreditCard primary key(ContactID,CreditCardID)
)
--seceond schema
create table Purchasing.PurchaseOrderHeader
(
	PurchaseOrderID int not null,
	ShipMethodID int not null,
	RevisionNumber bigint,
	Status varchar(20),
	EmployeeID int,
	VendorID int,
	OrderDate date,
	Shipdate date,
	SubTotal bigint,
	TaxAmt bigint,
	Freight varchar(20),
	TotalDue bigint,
	ModifiedDate date
	constraint pk_PurchaseOrderHeader primary key (PurchaseOrderID,ShipMethodID)
)
create table Purchasing.Vendor
(
	VendorID int primary key,
	AccountNumber bigint,
	Name varchar(100),
	CreditRating varchar(20),
	PreferredVendorStatus varchar(20),
	ActiveFlag bit,
	PurchasingWebServiceURL varchar(20),
	ModifiedDate date,
)
create table Purchasing.VendorContact
(
	VendorID int not null,
	ContactID int not null,
	ContactTypeID int,
	ModifiedDate date,
	constraint pk_VendorContact primary key (VendorID,ContactID)
)
create table Purchasing.PurchaseOrderDetail
(
	ShipMethodID int not null,
	PurchaseOrderID int not null,
	PurchaseOrderDetailID int not null,
	DueDate date,
	OrderQty bigint,
	ProcductID bigint,
	UnitPrice bigint,
	LineTotal bigint,
	ReceivedQty bigint,
	RejectQty bigint,
	StockedQty bigint,
	ModifiedDate date,
	constraint pk_purchaseOrderDetail primary key (ShipMethodID,PurchaseOrderID,PurchaseOrderDetailID)
)
create table Purchasing.VendorAddress
(
	VendorID int not null,
	AddressID int not null,
	AddressTypeID int,
	ModifiedDate date
	constraint pk_VendorAddress primary key (VendorID,AddressID)
)
create table Purchasing.ShipMethod
(
	ShipMethodID int primary key,
	Name varchar(100),
	Shipbase varchar(20),
	ShipRate decimal,
	rowguid int unique,
	ModifiedDate date,
)
create table Purchasing.ProductVendor
(
	ProductID int not null,
	VendorID int not null,
	AverageLeadTime varchar(20),
	StandardPrice decimal,
	LastReceiptCost Decimal,
	LastReceiptdate date,
	MinOrderQty int,
	MaxOrderQty int,
	OnOrderQty int,
	UnitMeasureCode varchar(20),
	ModifiedDate date,
	constraint pk_ProductVendor primary key (ProductID,VendorID)
)



--production


create table Production.ProductReview
(
	ProductReviewID int primary key,
	ProductID int,
	ReviewerName varchar(100),
	ReviewDate date,
	EmailAddress varchar(100),
	Rating varchar(100),
	Comments varchar(100),
	ModifiedDate date
)
create table Production.ProductListPriceHistory
(
	ProductID int,
	StartDate date,
	EndDate date,
	ListPrice decimal,
	ModifiedDate date,
	constraint pk_ProductListPriceHistory primary key (ProductID,StartDate)
)
create table Production.BillOfMaterials
(
	BillOdMaterialsID int primary key,
	ProductAssemblyID int unique,
	CompomentID int unique,
	StartDate date unique,
	EndDate date,
	UnitMeeasureCode varchar(100),
	BOMLevel varchar(100),
	PerAssemblyQty int,
	ModifiedDate date
)
create table Production.UnitMeasure
(
	UnitMeasureCode varchar(100) primary key,
	Name varchar(100) unique,
	ModifiedDate date,
)
create table Production.TransactionHistory
(
	TransactionID int primary key,
	ProductID int,
	ReferenceOrderID int,
	TransactionDate date,
	TransactionType varchar(100),
	Quantity int,
	ActualCost decimal,
	ModifiedDate date,
	ReferenceOrderLineID int,
)
create table Production.Product
(
	ProductID int primary key,
	Name varchar(100) unique,
	ProductNumber int unique,
	MakeFlag bit,
	FinishedGoodsFlag bit,
	Color varchar(100),
	SafetyStockLevel varchar(100),
	ReorderPoint varchar(100),
	StandardCost decimal,
	ListPrice decimal,
	Size int,
	SizeUnitMeasureCode varchar(100),
	WeigthUnitMeasureCode varchar(100),
	Weight decimal,
	DaysToManufacture int,
	ProductLine varchar(100),
	Class varchar(100),
	Style varchar(100),
	ProductSubcategoryID int,
	ProductModelID int,
	SellStartDate date,
	SellEndDate date, 
	DiscontinuedDate date,
	rowguid int unique,
	ModifiedDate date
)
create table Production.ProductPhoto
(
	ProductPhotoID int primary key,
	ThumbnailPhoto varchar(100),
	ThumbnailPhotoFileName varchar(100),
	LargePhoto varchar(100),
	LargePhotoFileName varchar(100),
	ModifedDate date,
)
create table Production.ProductProductPhoto
(
	ProductID int,
	ProductPhotoID int,
	[Primary] varchar(100),
	ModifiedDate date,
	constraint pk_ProductProductPhoto primary key (ProductID,ProductPhotoID)
)
create table Production.ProductSubcategory
(
	ProductSubcategoryID int primary key,
	ProductCategoryID int,
	Name varchar(100) unique,
	rowguid int unique,
	ModifiedDate date
)
create table Production.ProductCostHistory
(
	ProductID int,
	StartDate date,
	EndDate date,
	StandardCost decimal,
	ModifiedDate decimal,
	constraint pk_ProductCostHistory primary key (ProductID,StartDate)
)
create table Production.ProductInventory
(
	ProductID int,
	LocationID int,
	Shelf varchar(100),
	Bin varchar(100),
	Quantity int,
	rowguid int unique,
	ModifiedDate date,
	constraint pk_ProductInventory primary key(ProductID,LocationID)
)
create table Production.Location
(
	LocationID int primary key,
	Name int unique,
	CostRate decimal,
	Availability varchar(100),
	ModifiedDate date
)
create table Production.WorkOrderRouting
(
	WorkOrderID int,
	ProductID int,
	OperationSequence varchar(100),
	LocationID int,
	ScheduleStartDate date,
	ScheduleEndDate date,
	ActualStartDate date,
	ActualEndDate date,
	ActualResourceHrs varchar(100),
	PlannedCost decimal,
	ActualCost decimal,
	ModifiedDate date,
	constraint pk_WorkOrderRouting primary key(WorkOrderID,ProductID,OperationSequence)
)
create table Production.WorkOrder
(
	WorkOrderID int primary key,
	ProductID int,
	OrderQty int,
	StockedQty int,
	ScrappedQty int,
	StartDate date,
	EndDate date,
	DueDate date,
	ScrapReasonID int,
	ModifiedDate date
)
create table Production.ProductCategory
(
	ProductCategoryID int primary key,
	Name varchar(100) unique,
	rowguid int unique,
	ModifiedDate date
)
create table Production.ProductDocument
(
	ProductID int,
	DocumentID int,
	ModifiedDate date,
	constraint pk_ProductDocument primary key (ProductID,DocumentID)
)
create table Production.Document
(
	DocumentID int primary key,
	Title varchar(100),
	FileName varchar(100) unique,
	FileExtension varchar(100),
	Revision varchar(100) unique,
	ChangeNumber varchar(100),
	Status varchar(100),
	DocumentSummary varchar(100),
	Document varchar(100),
	ModifedDate date
)
create table Production.ProductModel
(
	ProductModelID int primary key,
	Name varchar(100) unique,
	CatalogDescription varchar(100),
	Instruction varchar(100),
	rowguid int unique,
	ModifiedDate date
)
create table Production.ProductModelIllustration
(
	ProductionModelID int,
	IllustrationID int,
	Modifieddate date,
	constraint pk_ProductModelIllustration primary key(ProductionModelID,IllustrationID)
)
create table Production.Illustration
(
	IllustrationID int,
	Diagram varchar(100),
	ModifiedDate date
)
create table Production.ProductModelProductDescriptionCulture
(
	ProductModelID int,
	ProductDescriptionID int,
	CultureID int,
	ModifiedDate date,
	constraint pk_ProductModelProductDescriptionCulture primary key(ProductModelID,ProductDescriptionID,CultureID)
)
create table Production.ProductDescription
(
	ProductDescriptionID int primary key,
	Description varchar(100),
	rowguid int unique,
	ModifiedDate date
)
create table Production.Culture
(
	CultureID int primary key,
	Name varchar(100) unique,
	ModifiedDate date
)
create table Production.TransactionHistoryArchive
(
	TransactionID int primary key,
	ProductID int,
	ReferenceOrderID int,
	TransactionDate date,
	TransactionType varchar(100),
	Quantity int,
	ActualCost decimal,
	ModifiedDate date,
	ReferenceOrderLineID int
)
create table Production.ScrapReason
(
	ScrapReasonID int primary key,
	Name varchar(100) unique,
	ModifiedDate date
)

--person

create table Person.ContactType
(
	ContactTypeID int primary Key,
	Name varchar(100) unique,
	ModifiedDate date
)
create table Person.Contact
(
	ContactID int primary Key,
	NameStyle  varchar(100),
	Title varchar(100),
	FirstName varchar(100),
	MiddleName varchar(100),
	LastName varchar(100),
	Suffix varchar(100),
	EmailAddress varchar(100),
	EmailPromotion varchar(100),
	Phone varchar(100),
	PasswordHash varchar(100),
	PasswordSalt varchar(100),
	AdditionalContactInfo varchar(100),
	rowguid int unique,
	ModifiedDate date,
)
create table Person.AddressType
(
	AddressTypeID int primary Key,
	Name varchar(100) unique,
	rowguid int unique,
	ModifiedDate date
)
create table Person.Address
(
	AddressID int primary Key,
	AddressLine1  varchar(100) unique,
	AddressLine2  varchar(100) unique,
	City  varchar(100) unique,
	StateProvinceID int unique,
	PotalCode int unique,
	rowguid int unique,
	ModifiedDate date
)
create table Person.StateProvince
(
	StateProvinceID int primary Key,
	StateprovinceCode int unique,
	CountryRegionCode int unique,
	IsOnlyStateProvinceFlag bit,
	Name varchar(100) unique,
	TerritoryID int,
	rowguid int unique,
	ModifiedDate date
)
create table Person.CountryRegion
(
	CountryRegionCode  varchar(100) primary Key,
	Name varchar(100) unique,
	ModifiedDate date
)

--Human Resources
create table HumanResources.EmployeeDepartmentHistory
(
	EmployeeID int,
	DepartmentID int,
	StartDate int,
	ShiftID int,
	EndDate date,
	ModifiedDate date,
	constraint pk_EmployeeDepartmentHistory primary key(EmployeeID,DepartmentID,StartDate,ShiftID)
)
create table HumanResources.Shift
(
	ShiftID int,
	Name varchar(100) unique,
	StartTime time unique,
	EndTime time unique,
	ModifiedDate date,
	constraint pk_Shift primary key(ShiftID)
)
create table HumanResources.JobCandidate
(
	JobCandidateID int,
	EmployeeID int,
	Resume varchar(100),
	ModifiedDate date,
	constraint pk_JobCandidate primary key(JobCandidateID)
)
create table HumanResources.EmployeePayHistory
(
	EmployeeID int,
	RateChangeDate date,
	Rate decimal,
	PayFrequency varchar(100),
	ModifiedDate date,
	constraint pk_EmployeePayHistory primary key(EmployeeID,RateChangeDate)
)
create table HumanResources.EmployeeAddress
(
	EmployeeID int,
	AddressID int,
	rowguid int unique,
	ModifiedDate date,
	constraint pk_EmployeeAddress primary key(EmployeeID,AddressID)
)
create table HumanResources.Employee
(
	EmployeeID int,
	NationalIDNumber int unique,
	ContactID int,
	LoginID int unique,
	ManagerID int,
	ShiftID int,
	Title varchar(100),
	BirthDate date,
	MaritalStatus varchar(100),
	Gender  varchar(100),
	HireDate date,
	SalariedFlag bit,
	VacationHours int,
	SickLeaveHours int,
	CurrentFlag bit,
	rowguid int unique,
	ModifiedDate date,
	constraint pk_Employee primary key(EmployeeID)
)
create table HumanResources.Department
(
	DepartmentID int,
	Name varchar(100) unique,
	GroupName varchar(100),
	ModifiedDate date,
	constraint pk_Department primary key(DepartmentID)
)