create database classrm_batch
use classrm_batch

drop table day4_sql
create table day4_sql
(
	id int primary key identity,
	batch_no varchar(10)
)
declare @i int=1
while @i <= 30
begin
insert into day4_sql values
(
	concat('CHN17ID',RIGHT('00'+CONVERT(varchar,@i),3))
)
set @i = @i +1
end
select * from day4_sql

use NORTHWND

with count_name as
(
select Products.ProductName,YEAR(o.OrderDate) as 'YearOrdered' from Products
inner join [Order Details] as od on Products.ProductID=od.ProductID
inner join Orders as o on od.OrderID=o.OrderID
group by YEAR(o.OrderDate),Products.ProductName
)
select ProductName,[year1] as '1996',[year2] as '1997',[year3] as '1998'
from count_name
PIVOT
(
count(ProductName)
for YearOrdered in([year1],[year2],[year3])
) piv;

select *
from 
(select sum(od.Quantity) as 'SumOfQuantity',ProductName,YEAR(o.OrderDate) as 'YearOrdered' from Products
inner join [Order Details] as od on Products.ProductID=od.ProductID
inner join Orders as o on od.OrderID=o.OrderID
group by ProductName,YEAR(o.OrderDate)) as pro
PIVOT
(
sum(SumOfQuantity)
for YearOrdered in([1996],[1997],[1998])
) piv;
