SpecialOffer
CreditCard
SpecialOfferProduct
SalesReason
SalesOrderDetails
Currency
ShoppingCartItem