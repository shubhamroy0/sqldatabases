use TRICARE

create table Userlogin
(
	UserID int primary key,
	Email varchar(50) unique,
	[Password] varchar(100),
	RoleID int
)
go
create table [User]
(
	UserID int identity primary key,
	FirstName varchar(150),
	LastName varchar(150),
	Age int,
	EmailID varchar(50) unique,
	PhoneNumber varchar(50) unique,
	[Address] varchar(550)
)
go
create table Comments
(
	CommentID int identity primary key,
	[Description] varchar(5000),
	RegulationID int,
	UserID int,
	DateOfRegistration date
)
go
create table [Role]
(
	RoleID int identity primary key,
	RoleType varchar(50)
)
go
create table EmployeeDepartment
(
	UserID int,
	DepartmentID int,
	Constraint PK_EmployeeDepartment primary key (UserID,DepartmentID)
)
go
create table Regulations
(
	RegulationID int identity primary key,
	RegulationName varchar(100),
	RegulationDetails varchar(100),
	DateCreated date,
	RegulationTypeID int
)
go
create table Department
(
	DepartmentID int identity primary key,
	DepartmentName varchar(100),
	DepartmentDescription varchar(1000),
	DepartmentHead int,
)
go
create table RegulationDepartmnt
(
	RegulationID int,
	DepartmentID int,
	DateModified date
	Constraint PK_RegulationDepartmnt primary Key (RegulationID,DepartmentID)
)
go
create table RegulationType
(
	RegulationTypeID int identity primary key,
	RegulationTypeName varchar(100),
	RegulationTypeDetails varchar(1000)
)
go

Alter table UserLogin
ADD CONSTRAINT FK_UserLogin Foreign key ([UserID]) REFERENCES [User](UserID)

Alter table UserLogin
ADD CONSTRAINT FK_UserLogin_Role Foreign key ([RoleID]) REFERENCES [Role](RoleID)

Alter table Comments
ADD CONSTRAINT FK_Comments Foreign key ([RegulationID]) REFERENCES Regulations(RegulationID)

Alter table Comments
ADD CONSTRAINT FK_Comments_UserID Foreign key ([UserID]) REFERENCES [User](UserID)

Alter table Regulations
ADD CONSTRAINT FK_Regulations_RegulationTypeID Foreign key (RegulationTypeID) REFERENCES RegulationType(RegulationTypeID)

Alter table RegulationDepartmnt
ADD 
CONSTRAINT FK_RegulationDepartmnt_Regulation 
Foreign key (RegulationID) REFERENCES Regulations(RegulationID),
CONSTRAINT FK_RegulationDepartmnt_Department 
Foreign key (DepartmentID) REFERENCES Department(DepartmentID)

Alter table EmployeeDepartment
ADD 
CONSTRAINT FK_EmployeeDepartment_UserID
Foreign key (UserID) REFERENCES [User](UserID),
CONSTRAINT FK_EmployeeDepartment_DepartmentID
Foreign key (DepartmentID) REFERENCES Department(DepartmentID)

Alter table Department
ADD
CONSTRAINT FK_Department_DepartmentHead 
FOREIGN KEY (DepartmentHead) REFERENCES [user](UserID)