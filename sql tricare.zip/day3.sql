select * from Products
go

select * from orders
go
select * from Customers
go
select EmployeeId from (select EmployeeID,count(EmployeeID) as count_empid from Orders
group by EmployeeID order by count_empid desc) where rownum=1
go
	select c.ContactName,p.ProductName   order by c.ContactName asc
go
select * from [order details]
go
with joint_tables as
(
select c.CompanyName,od.UnitPrice,od.Discount,od.Quantity from customers as c
inner join orders on orders.CustomerID=c.CustomerID
inner join [Order Details] as od on od.OrderID=orders.OrderID
)
select 
	CompanyName,
	sum(Quantity) as count_of_products,
	sum(UnitPrice*Quantity),
	cast(sum((UnitPrice-(UnitPrice*discount))*Quantity) as decimal(10,2)) 
from joint_tables 
group by CompanyName 
order by CompanyName asc


with joint_table as
(
select e.EmployeeID,count(o.OrderID) as CountOfOrder
from Employees as e
inner join orders as o on o.EmployeeID=e.EmployeeID
group by e.EmployeeID
)
select distinct e.FirstName,e.LastName,e.Title,e.BirthDate,e.HireDate
from Employees as e
where e.EmployeeID=(select EmployeeID from joint_table where CountOfOrder=(select min(CountOfOrder) from joint_table))

select P.ProductID,
 P.ProductName, 
 YEAR(O.OrderDate) as 'year', 
 MONTH(O.OrderDate) as 'month',  
 DAY(O.OrderDate)as 'day', 
 DATENAME(dw, O.OrderDate) as 'day name'
from orders as o 
inner join [Order Details] as od on od.OrderID=o.OrderID
inner join [Products] as p on p.ProductID=od.ProductID where
day(o.OrderDate) = '1'

go
with avg_price as
(select categoryID,avg(UnitPrice) as avg_p from Products group by CategoryID)
select productname,avg_p,UnitPrice from Products 
inner join  avg_price on Products.CategoryID=avg_price.CategoryID 
where Products.UnitPrice > avg_p

select Products.ProductName,
c.CompanyName,
e.FirstName,
CONVERT(varchar(10),o.ShippedDate,110)AS 'ShippedDate',
DATEDIFF(DAY,o.RequiredDate,o.ShippedDate) as 'Day',
DATEDIFF(HOUR,o.RequiredDate,o.ShippedDate) as 'Hour',
DATEDIFF(MINUTE,o.RequiredDate,o.ShippedDate) as 'Minute',
CONVERT(varchar(10),o.RequiredDate,110) as 'RequiredDate' 
from products 
inner join [Order Details] as od on od.ProductID=Products.ProductID
inner join Orders as o on o.OrderID=od.OrderID
inner join Customers as c on o.CustomerID=c.CustomerID
inner join Employees as e on E.EmployeeID=o.EmployeeID
where o.ShippedDate > o.RequiredDate

with count_table as
(select count(OrderID) as count_id
from Orders group by CustomerID)
select count_id from count_table where rownum=3 order by count_id desc

